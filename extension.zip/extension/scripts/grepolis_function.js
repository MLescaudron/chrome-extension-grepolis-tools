/**
 * How many second to wait
 * @type {number}
 */
var second = 300;
/**
 *  Start the automate
 */
$('button#starting').on('click', function () {
    if($(this).text() == 'Start'){
        $('#time_to_end').css('color','#75d95a');
        readyToRestart();
        $(this).text('Stop');
    } else {
        second = false;
        $('#time_to_end').css('color','white');
        $(this).text('Start');
    }
});

/**
 * Restart the automate
 */
function readyToRestart() {

    can_click = 0;
    var action = ($('#looting').is(':checked')) ? 'double' : 'normal';

    var town = 0;
    var id = 0;

    var wood = parseInt($('.wood .amount').text());
    var stone = parseInt($('.stone .amount').text());
    var iron = parseInt($('.iron .amount').text());

    for (var id = 0; id < $('.farmtown_owned_on_same_island').length; id++) {

        town = $('.farmtown_owned_on_same_island')[id];
        townId = $(town).attr('id').replace('farm_town_', '');

        $.ajax({
            url: 'https://' + window.Game.world_id + '.grepolis.com/game/farm_town_info?town_id=' + window.Game.townId + '&action=claim_load&h=' + window.Game.csrfToken,
            data: {
                'json': '{"target_id":"' + townId + '","claim_type":"'+action +'","time":300,"town_id":' + window.Game.townId + ',"nl_init":true}',

            },
            type: 'post',
            dataType: 'json',
            success: function (json) {
                console.log(json);

                wood += 20;
                stone += 20;
                iron += 20;

                $('.wood .amount').text(wood);
                $('.stone .amount').text(stone);
                $('.iron .amount').text(iron);
            },
            error: function (e, x, t) {
                console.log('error');
            },
        });
    }
    second = 300;
    setTimeout(waitMe, 1000);
}

/**
 * The Timer
 * @returns {boolean}
 */
function waitMe() {

    if(second == false){
        second = 300;
        $('#time_to_end').html(second + 's');
        return false;
    }

    $('#time_to_end').html(second + 's');
    second--;
    if (second <= 0) {
        readyToRestart();
        return false;
    }

    setTimeout(waitMe, 1000);
}